// ============================================
// WEATHER DATA
// ============================================
const weatherData = {
    'new york': { temp: 24, desc: 'Partly Cloudy', humidity: '68%', wind: '14 km/h', uv: 'UV 5', aqi: 'AQI 42', outfit: '👕 Light cotton + sunglasses' },
    'london': { temp: 16, desc: 'Light Rain', humidity: '82%', wind: '22 km/h', uv: 'UV 2', aqi: 'AQI 28', outfit: '🧥 Raincoat + umbrella' },
    'tokyo': { temp: 28, desc: 'Sunny', humidity: '55%', wind: '10 km/h', uv: 'UV 7', aqi: 'AQI 35', outfit: '👕 Shorts + cap' },
    'sydney': { temp: 32, desc: 'Clear', humidity: '45%', wind: '18 km/h', uv: 'UV 8', aqi: 'AQI 22', outfit: '👕 Linen + sunglasses' },
    'mumbai': { temp: 34, desc: 'Hazy', humidity: '70%', wind: '12 km/h', uv: 'UV 6', aqi: 'AQI 78', outfit: '🧴 Cotton + sunscreen' },
    'default': { temp: 24, desc: 'Partly Cloudy', humidity: '68%', wind: '14 km/h', uv: 'UV 5', aqi: 'AQI 42', outfit: '👕 Light cotton + sunglasses' }
};

let currentCity = 'new york';

// ============================================
// DOM REFS
// ============================================
const cityName = document.getElementById('cityName');
const tempDisplay = document.getElementById('tempDisplay');
const descDisplay = document.getElementById('descDisplay');
const humidity = document.getElementById('humidity');
const wind = document.getElementById('wind');
const uv = document.getElementById('uv');
const aqi = document.getElementById('aqi');
const outfitText = document.getElementById('outfitText');
const forecastList = document.getElementById('forecastList');
const healthAdvice = document.getElementById('healthAdvice');
const travelAdvice = document.getElementById('travelAdvice');
const activityGrid = document.getElementById('activityGrid');
const updateTime = document.getElementById('updateTime');

const chatToggle = document.getElementById('chatToggle');
const chatBox = document.getElementById('chatBox');
const chatMessages = document.getElementById('chatMessages');
const chatInput = document.getElementById('chatInput');
const chatSendBtn = document.getElementById('chatSendBtn');

// ============================================
// UPDATE WEATHER UI
// ============================================
function updateWeather(cityKey) {
    const key = cityKey.toLowerCase().trim();
    const data = weatherData[key] || weatherData['default'];
    currentCity = key;

    cityName.innerHTML = `${key.charAt(0).toUpperCase()+key.slice(1)} <small>${key.slice(0,2).toUpperCase()}</small>`;
    tempDisplay.textContent = data.temp + '°';
    descDisplay.textContent = data.desc;
    humidity.textContent = data.humidity;
    wind.textContent = data.wind;
    uv.textContent = data.uv;
    aqi.textContent = data.aqi;
    outfitText.textContent = data.outfit;

    // Forecast
    const days = ['Mon','Tue','Wed','Thu','Fri','Sat','Sun'];
    const icons = ['fa-cloud-sun','fa-cloud-rain','fa-sun','fa-cloud','fa-cloud-sun','fa-sun','fa-cloud-rain'];
    const temps = [22,19,26,21,24,27,18];
    let forecastHtml = '';
    for (let i=0; i<5; i++) {
        const day = days[(new Date().getDay() + i) % 7];
        const icon = icons[(new Date().getDay() + i) % 7];
        const t = temps[(new Date().getDay() + i) % 7];
        forecastHtml += `<div class="day-item">${day} <i class="fas ${icon}"></i> ${t}°</div>`;
    }
    forecastList.innerHTML = forecastHtml;

    // Health
    const healthMsgs = [
        '<i class="fas fa-check-circle" style="color:#1f6e4a;"></i> Asthma: Low risk',
        '<i class="fas fa-check-circle" style="color:#1f6e4a;"></i> Allergy: Moderate (pollen)',
        '<i class="fas fa-exclamation-triangle" style="color:#c97d2b;"></i> Elderly: Stay hydrated'
    ];
    if (key === 'mumbai') healthMsgs[1] = '<i class="fas fa-exclamation-triangle" style="color:#c97d2b;"></i> Allergy: High (dust)';
    if (key === 'london') healthMsgs[0] = '<i class="fas fa-exclamation-triangle" style="color:#c97d2b;"></i> Asthma: Moderate (damp)';
    healthAdvice.innerHTML = healthMsgs.map(m => `<li>${m}</li>`).join('');

    // Travel
    let travelMsg = '<li><i class="fas fa-shield-alt" style="color:#1f6e4a;"></i> Overall: <strong style="color:#1a6b4a;">Safe</strong></li>';
    if (key === 'london') travelMsg = '<li><i class="fas fa-shield-alt" style="color:#c97d2b;"></i> Overall: <strong style="color:#b46f1e;">Moderate</strong></li>';
    travelAdvice.innerHTML = travelMsg + '<li><i class="fas fa-road"></i> Visibility: Good</li><li><i class="fas fa-wind"></i> Wind: Moderate</li><li><span class="tag" style="background:#1a6b4a20;">✔️ Recommended</span></li>';

    // Activities
    const activities = [
        { icon: 'fa-walking', name: 'Walking', status: '🌤️' },
        { icon: 'fa-bicycle', name: 'Cycling', status: (key==='london'?'🌧️':'🌤️') },
        { icon: 'fa-camera', name: 'Photography', status: (key==='mumbai'?'☁️':'🌤️') },
        { icon: 'fa-tree', name: 'Hiking', status: (key==='sydney'?'☀️':'⚠️') }
    ];
    activityGrid.innerHTML = activities.map(a => 
        `<div class="activity-item"><i class="fas ${a.icon}"></i><span class="name">${a.name}</span> <span style="margin-left:auto; font-size:0.7rem; background:#d1e7f0; padding:2px 10px; border-radius:40px;">${a.status}</span></div>`
    ).join('');

    updateTime.textContent = new Date().toLocaleTimeString();
}

// ============================================
// AI CHAT ASSISTANT
// ============================================
function getAIResponse(question, city) {
    const data = weatherData[city] || weatherData['default'];
    const q = question.toLowerCase().trim();

    if (q.includes('rain') || q.includes('rainy') || q.includes('rainfall')) {
        const rainChance = city === 'london' ? '80%' : city === 'new york' ? '30%' : '20%';
        const advice = city === 'london' ? ' Yes, expect rain. Carry an umbrella! 🌂' : ' No rain expected today. Enjoy! ☀️';
        return `🌧️ Rain forecast: ${rainChance} chance.${advice}`;
    }
    else if (q.includes('wear') || q.includes('outfit') || q.includes('clothes')) {
        return `👕 Outfit suggestion: ${data.outfit} (${data.temp}°C, ${data.desc})`;
    }
    else if (q.includes('temperature') || q.includes('temp') || q.includes('hot') || q.includes('cold')) {
        return `🌡️ Current temperature in ${city}: ${data.temp}°C with ${data.desc.toLowerCase()}.`;
    }
    else if (q.includes('activity') || q.includes('outdoor') || q.includes('outside') || q.includes('go out')) {
        const good = data.temp > 18 && data.temp < 30 && !city.includes('london');
        return good ? 
            '🏃 Great weather for outdoor activities! Perfect for walking, cycling, or hiking.' :
            '⚠️ Weather may not be ideal for outdoor activities. Consider indoor options.';
    }
    else if (q.includes('travel') || q.includes('safe') || q.includes('drive')) {
        const safe = city !== 'london';
        return safe ? 
            '🚗 Travel conditions are safe. Good visibility and moderate winds.' :
            '⚠️ Travel conditions are moderate. Drive carefully due to rain.';
    }
    else if (q.includes('humidity') || q.includes('moist')) {
        return `💧 Humidity is at ${data.humidity}. ${parseInt(data.humidity) > 70 ? 'Quite humid, stay hydrated!' : 'Comfortable levels.'}`;
    }
    else if (q.includes('uv') || q.includes('sunburn') || q.includes('sun')) {
        return `☀️ UV index: ${data.uv}. ${parseInt(data.uv.replace('UV ','')) > 6 ? 'High UV! Wear sunscreen.' : 'Moderate UV, safe for outdoor.'}`;
    }
    else if (q.includes('aqi') || q.includes('air quality') || q.includes('pollution')) {
        return `🌬️ Air Quality: ${data.aqi}. ${parseInt(data.aqi.replace('AQI ','')) > 50 ? 'Moderate, sensitive groups should limit outdoor.' : 'Good air quality.'}`;
    }
    else if (q.includes('hello') || q.includes('hi') || q.includes('hey')) {
        return '👋 Hello! How can I help you with the weather today?';
    }
    else {
        return `🤔 I'm not sure about that. Try asking about: rain, outfit, temperature, activities, travel, humidity, UV, or AQI.`;
    }
}

// ============================================
// CHAT FUNCTIONS
// ============================================
function addMessage(text, sender) {
    const div = document.createElement('div');
    div.className = `chat-msg ${sender}`;
    const time = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    div.innerHTML = `${text} <span class="time">${time}</span>`;
    chatMessages.appendChild(div);
    chatMessages.scrollTop = chatMessages.scrollHeight;
}

function handleQuestion(question) {
    if (!question.trim()) return;
    addMessage(question, 'user');
    const city = currentCity;
    const response = getAIResponse(question, city);
    setTimeout(() => {
        addMessage(response, 'ai');
    }, 400);
    chatInput.value = '';
}

// ============================================
// EVENT LISTENERS
// ============================================
document.getElementById('searchBtn').addEventListener('click', function() {
    const input = document.getElementById('cityInput');
    if (input.value.trim() !== '') updateWeather(input.value.trim());
});

document.getElementById('cityInput').addEventListener('keypress', function(e) {
    if (e.key === 'Enter') document.getElementById('searchBtn').click();
});

document.getElementById('favBtn').addEventListener('click', function() {
    const city = document.getElementById('cityInput').value.trim();
    alert(`⭐ ${city} saved to favorites!`);
});

chatToggle.addEventListener('click', function() {
    chatBox.classList.toggle('active');
    chatToggle.innerHTML = chatBox.classList.contains('active') ? 
        '<i class="fas fa-times"></i> Close Chat' : 
        '<i class="fas fa-comment-dots"></i> Open Chat';
    if (chatBox.classList.contains('active')) {
        chatInput.focus();
    }
});

chatSendBtn.addEventListener('click', function() {
    handleQuestion(chatInput.value);
});

chatInput.addEventListener('keypress', function(e) {
    if (e.key === 'Enter') handleQuestion(chatInput.value);
});

document.querySelectorAll('.quick-chips button').forEach(btn => {
    btn.addEventListener('click', function() {
        const q = this.dataset.question;
        handleQuestion(q);
    });
});

document.querySelector('.logo').addEventListener('dblclick', function() {
    document.getElementById('cityInput').value = 'New York';
    updateWeather('new york');
    chatMessages.innerHTML = '';
    addMessage('👋 Hi! I\'m your AI weather assistant. Ask me about: rain, outfit, temperature, activities, travel, humidity, UV, or AQI.', 'ai');
});

// ============================================
// INITIAL LOAD
// ============================================
updateWeather('new york');